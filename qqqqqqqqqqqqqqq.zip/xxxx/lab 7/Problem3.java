package com.lab7;

import java.util.*;
public class Problem3 {

	public static void getSquares(int a[], HashMap<Integer, Integer>hm)
	{
		int s=0,key=0;
		for(int i=0;i<a.length;i++)
		{
			key=a[i];
			s=a[i]*a[i];
			hm.put(key,s);
			
		}
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		Problem3 p3=new Problem3();
		
		System.out.println("Enter the size of an array:");
		int n=sc.nextInt();
		int arr[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the "+(i+1)+" element:");
			int num=sc.nextInt();
			arr[i]=num;
		}
		
		HashMap<Integer, Integer> hash_map = new HashMap<Integer, Integer>();
		
		p3.getSquares(arr, hash_map);
		System.out.println(hash_map);
		
	}

}
