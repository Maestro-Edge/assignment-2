package com.lab2;

class CD extends MediaItem {
	
	private String artist, genre;

	CD(String title, int id, int copies) {
		super(title, id, copies);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void setRuntime(int runtime) {
		// TODO Auto-generated method stub
		super.setRuntime(runtime);
	}
	
	@Override
	public int getRuntime() {
		// TODO Auto-generated method stub
		return super.getRuntime();
	}
	
	public void setArtist(String artist) {
		this.artist = artist;
	}
	
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	public String getArtist() {
		return artist;
	}
	
	public String getGenre() {
		return genre;
	}
	
	

}
