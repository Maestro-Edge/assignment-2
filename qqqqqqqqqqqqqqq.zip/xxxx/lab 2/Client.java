package com.lab2;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Client {
	
	Book book;
	JournalPaper journal;
	Video video;
	CD cd;
	
	static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
	
	//Book Data
	void setBookData(String title, int id, int copies)throws IOException
	{
		book = new Book(title, id, copies);
		
		System.out.print("Enter author's name: ");
		book.setAuthor(input.readLine());
	}
	void viewBookData()
	{
		System.out.println("Title: " +book.getTitle());
		System.out.println("ID: "+book.getId());
		System.out.println("No. of copies: "+book.getCopies());	
		System.out.println("Author's name: "+book.getAuthor());
	}
	
	//Journal Data
	void setJournalData(String title, int id, int copies)throws IOException
	{
		journal = new JournalPaper(title, id, copies);
		
		System.out.print("Enter author's name: ");
		journal.setAuthor(input.readLine());
		
		System.out.print("Enter publisher's name: ");
		journal.setPublisher(input.readLine());
	}
	void viewJournalData()
	{
		System.out.println("Title: " +journal.getTitle());
		System.out.println("ID: "+journal.getId());
		System.out.println("No. of copies: "+journal.getCopies());	
		System.out.println("Author's name: "+journal.getAuthor());
		System.out.println("Publisher's name: "+journal.getPublisher());
	}
	
	//Video data
	void setVideoData(String title, int id, int copies)throws IOException
	{
		video = new Video(title, id, copies);
		
		System.out.print("Enter runtime: ");
		video.setRuntime(Integer.parseInt(input.readLine()));
		
		System.out.println("Enter director, genre, year: ");
		video.setDirector(input.readLine());
		video.setGenre(input.readLine());
		video.setYear(Integer.parseInt(input.readLine()));
	}
	void viewVideoData()
	{
		System.out.println("Title: " +video.getTitle());
		System.out.println("ID: "+video.getId());
		System.out.println("No. of copies: "+video.getCopies());
		System.out.println("Runtime: "+video.getRuntime());
		System.out.println("Director: "+video.getDirector());
		System.out.println("Genre: "+video.getGenre());
		System.out.println("Year: "+video.getYear());
	}
	
	//CD data
	void setCdData(String title, int id, int copies)throws IOException
	{
		cd = new CD(title, id, copies);
		
		System.out.print("Enter runtime: ");
		cd.setRuntime(Integer.parseInt(input.readLine()));
		
		System.out.println("Enter artist, genre: ");
		cd.setArtist(input.readLine());
		cd.setGenre(input.readLine());
	}
	void viewCdData()
	{
		System.out.println("Title: " +cd.getTitle());
		System.out.println("ID: "+cd.getId());
		System.out.println("No. of copies: "+cd.getCopies());
		System.out.println("Runtime: "+cd.getRuntime());
		System.out.println("Artist: "+cd.getArtist());
		System.out.println("Genre: "+cd.getGenre());
	}
	
	public static void main(String[] args)throws IOException 
	{
		Client client = new Client();
		
		System.out.println("Enter your choice: ");
		System.out.println("1. Book");
		System.out.println("2. Journal Papers");
		System.out.println("3. Video");
		System.out.println("4. CD");
		
		int in = Integer.parseInt(input.readLine());
		
		System.out.println("Enter Title, ID, number of copies: ");
		
		String title = input.readLine();
		int id = Integer.parseInt(input.readLine());
		int copies = Integer.parseInt(input.readLine());
		
		if(in == 1)
		{
			client.setBookData(title, id, copies);
			client.viewBookData();
		}
		else if(in == 2)
		{
			client.setJournalData(title, id, copies);
			client.viewJournalData();
		}
		else if(in == 3)
		{
			client.setVideoData(title, id, copies);
			client.viewVideoData();
		}
		else if(in == 4)
		{
			client.setCdData(title, id, copies);
			client.viewCdData();
		}
		else
		{
			System.out.println("Wrong Input.");
		}
	}
}
