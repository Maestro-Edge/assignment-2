package com.lab2;

class Video extends MediaItem 
{
	private String director, genre;
	private int year;

	Video(String title, int id, int copies) {
		super(title, id, copies);
		// TODO Auto-generated constructor stub
	}
	
	public void setDirector(String director) {
		this.director = director;
	}
	
	public String getDirector() {
		return director;
	}
	
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	public String getGenre() {
		return genre;
	}
	
	public void setYear(int year) {
		this.year = year;
	}
	
	public int getYear() {
		return year;
	}
	
	@Override
	public void setRuntime(int runtime) {
		
		super.setRuntime(runtime);
	}
	
	@Override
	public int getRuntime() {
		
		return super.getRuntime();
	}
	
	

}