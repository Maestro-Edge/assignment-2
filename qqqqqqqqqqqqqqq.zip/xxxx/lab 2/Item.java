package com.lab2;

public abstract class Item
{
	
//	Using an inheritance hierarchy, design a Java program to model items at a 
//	library (books, journal articles, videos and CDs.) 
//	Have an abstract superclass called Item and include common information that the 
//	library must have for every item (such as unique identification number, title, and number of copies). 
//	No actual objects of type Item will be created - each actual item will be an 
//	object of a (non-abstract) subclass. Place item-type-specific behavior in subclasses 
//	(such as a video's year of release, a CD's musical genre, or a book's author). 
	
	String title;
	int id, copies;
	
	Item(String title, int id, int copies)
	{
		setValues(title, id, copies);
	}
	
	private void setValues(String title, int id, int copies)
	{
		setTitle(title);
		setId(id);
		setCopies(copies);
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setCopies(int copies) {
		this.copies = copies;
	}
	
	public String getTitle() {
		return title;
	}
	
	public int getId() {
		return id;
	}
	
	public int getCopies() {
		return copies;
	}
}

