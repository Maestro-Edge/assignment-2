package com.lab2;

abstract class WrittenItem extends Item
{
	private String author;
	
	public WrittenItem(String title, int id, int copies) {
		super(title, id, copies);
	}
	
	public void setAuthor(String author) {
		this.author = author;
	}
	
//	public abstract void setAuthor();
	
	public String getAuthor() {
		return author;
	}
}
