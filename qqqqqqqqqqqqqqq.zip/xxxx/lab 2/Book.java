package com.lab2;

class Book extends WrittenItem
{

	public Book(String title, int id, int copies) {
		super(title, id, copies);
	}
	
	@Override
	public void setAuthor(String author) {
		super.setAuthor(author);
	}
	
	@Override
	public String getAuthor() {
		return super.getAuthor();
	}
	
	
}