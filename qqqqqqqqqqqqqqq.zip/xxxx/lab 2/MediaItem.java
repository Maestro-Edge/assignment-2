package com.lab2;

public abstract class MediaItem extends Item
{
	private int runtime;

	MediaItem(String title, int id, int copies) {
		super(title, id, copies);
		
	}
	
	public void setRuntime(int runtime) {
		this.runtime = runtime;
	}
	
	public int getRuntime() {
		return runtime;
	}
}