package com.lab2;

class JournalPaper extends WrittenItem{
	
	private String publisher;
	public JournalPaper(String title, int id, int copies) {
		super(title, id, copies);
	}
	
	@Override
	public void setAuthor(String author) {
		// TODO Auto-generated method stub
		super.setAuthor(author);
	}
//	@Override
//	public void setAuthor(String author) {
//		// TODO Auto-generated method stub
//		this.author = author;
//	}
	
	@Override
	public String getAuthor() {
		// TODO Auto-generated method stub
		return super.getAuthor();
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	
	
	//TODO: Write Main here
}